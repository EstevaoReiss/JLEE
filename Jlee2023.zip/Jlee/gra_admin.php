<?php
include "conexao.php";

$dir = './fotosjlee/';
$tmpName = $_FILES['arquivo']['tmp_name'];
$name = $_FILES['arquivo']['name'];
$produto = $_POST['produto'];
$descricao=$_POST['descricao'];
$valor=$_POST['valor'];
$estoque=$_POST['estoque'];
$categoria=$_POST['categoria'];

$select = $conn->prepare('SELECT count(*) AS count FROM produtos WHERE produto = :produto');

$select->execute(array(

    ':produto' => $produto,

));

foreach ($select as $linha) {

    if ($linha['count'] >= 1) {

        echo "<script>alert('ERRO: este usuário já existe');history.go(-1);</script>";

    } else {

        if (move_uploaded_file($tmpName, $dir . $name)) {
            // Arquivo movido com sucesso

        } else {

            echo "Erro ao gravar o arquivo";

        }

        if (isset($_POST['salvar'])) {

            if (($produto == "") || ($descricao == "") || ($name == "") || ($valor == "") || ($estoque == "") || ($name == "")) {

                echo "<script>alert('Campos não podem ser vazios!!!');history.go(-1);</script>";

            } else {

                $dados = $conn->prepare('INSERT INTO produtos (produto, descricao, imagem, valor, estoque, categoria) VALUES (:produto, :descricao, :imagem, :valor, :estoque, :categoria)');

                $dados->execute(array(

                    ':produto' => $produto,
                    ':descricao' => $descricao,
                    ':valor' => $valor,
                    ':imagem' => $name,
                    ':estoque' => $estoque,
                    ':categoria' => $categoria,

                ));

                if ($dados->rowCount() == 1) {

                    $codigo = $conn->lastInsertId();

                    echo '<script type="text/javascript">'; 
                    echo 'alert("Adcionado com sucesso");'; 
                    echo 'window.location.href ="admin.html";';
                    echo '</script>';

                } else {

                    echo "<script>alert('Erro ao incluir');history.go(-1);</script>";
                    
                }
            }
        }
        
    }
    
}
?>
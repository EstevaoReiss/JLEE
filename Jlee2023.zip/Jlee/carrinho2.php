<?php
    include "conexao.php";

    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    if(isset($_GET['id'])) {
        $id = $_GET['id'];
        $result = mysqli_query($con,"SELECT * FROM produtos WHERE id='$id'");
        $row = mysqli_fetch_array($result);

        if(isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity']++;
        } else {
            $_SESSION['cart'][$id] = array("quantity" => 1, "preço" => $row['preço']);
        }
    }

    if(isset($_GET['delete'])) {
        $id = $_GET['delete'];
        unset($_SESSION['cart'][$id]);
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Carrinho de Compras</title>
    <link rel="stylesheet" type="text/css" href="carrinho.css">
</head>
<body>

<div class="container">
    <h2>Carrinho de Compras</h2>
    <table>
        <tr>
            <th>Nome do Produto</th>
            <th>Quantidade</th>
            <th>Preço Unitário</th>
            <th>Preço Total</th>
            <th></th>
        </tr>
        <?php
            $total_price = 0;
            if(!empty($_SESSION['cart'])) {
                foreach($_SESSION['cart'] as $id => $value) {
                    $result = mysqli_query($con,"SELECT * FROM produtos WHERE id='$id'");
                    $row = mysqli_fetch_array($result);
                    $total_price += $row['preço'] * $value['quantidade'];
        ?>
        <tr>
            <td><?php echo $row['nome'];?></td>
            <td><?php echo $value['quantidade'];?></td>
            <td><?php echo $row['preço'];?></td>
            <td><?php echo $row['preço'] * $value['quantidade'];?></td>
            <td><a href="cart.php?delete=<?php echo $id;?>">Remover</a></td>
        </tr>
        <?php } } ?>
        <tr>
            <td colspan="3" style="text-align: right;">Total:</td>
            <td><?php echo $total_price;?></td>
            <td></td>
        </tr>
    </table>
</div>

</body>
</html>

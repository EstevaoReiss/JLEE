<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="fotosjlee/Coffee Shop Logo.jpg.png" type="image/x-icon">
    <title>JLEE Cafeteria - Tela de Bolo</title>
    <link rel="stylesheet" type="text/css" href="pagp.css" media="screen" />
</head>

    <body>
       
        <div class="topnav">
            <div class="Cadastrar">
              <a href="login.html" class="hoverborder"><img src="fotosjlee/usuario login.png" width="30px"heigth="50px" alt=""></a>
              <a href="entrar.html" class="hoverborder"><img src="fotosjlee/novo-usuario.png" width="30px"heigth="50px" alt=""></a>
            </div>
              <div class="logo">
                    <a href="index.html"><img src="fotosjlee/jlleeeeeeeeeeeeeeeeeeeeeee.jpg" alt="logotipo" width="140" height="140" ></a>
              </div>  
                  <header>
                  <div class="pescar">
            <input type="text" placeholder="Pesquisar..."class="pesquisar" >
            <br>
                   
            </div>
        </header>
        </div>
        <br> <br> <br> <br>

                <?php
                include "conexao.php";

                $check = $conn->prepare('SELECT * FROM produtos where id = "30"');

                $check->execute(array(

                ));

                if ($check->rowCount() > 0) {

                echo "<div>";
                foreach ($check as $linha) {
                echo "<div class='product'>";
                echo "<div class='nomeprod'>" . $linha['produto'] . "</div><br>";
                echo "<div class:'imagem'>";
                echo "<img src='fotosjlee/".$linha['imagem']."' class='imagem'><br>";
                echo "</div>";
                echo "<p class='tagp'> Uma criação francesa atemporal que combina a riqueza do presunto suculento, o sabor suave do queijo Gruyère derretido e a textura crocante do pão de forma dourado e gratinado. Cada mordida revela uma harmonia perfeita de sabores, com camadas de saboroso presunto defumado e queijo derretido entre fatias de pão torrado levemente. Preparado com maestria pelos nossos talentosos chefs, o Croque Monsieur na JLEE é a opção perfeita para os apreciadores de um lanche sofisticado e reconfortante. Seja para um almoço leve ou um momento de indulgência durante o dia, o Croque Monsieur é a escolha ideal para aqueles que buscam uma experiência culinária europeia autêntica. Venha provar a excelência do Croque Monsieur na JLEE e permita-se desfrutar de um sabor clássico e requintado, preparado com perfeição. </p><br><br><br><br><br><br><br><br><br><br><br>";
                echo "</div></a>";
                
                }
                echo "</div>";
                $query = "SELECT quantidade FROM produtos";

                if (isset($_POST['add'])) {
                    $numero += 1;
                } elseif (isset($_POST['sub'])) {
                    $numero -= 1;
                }
                }
                ?>

<footer class="rodape" id="contato">
      <div class="rodape-div">

          <div class="rodape-div-1">
              <div class="rodape-div-1-coluna">
                  <!-- elemento -->
                  <span><b>Endereço</b></span>
                  <p>Alameda Vale dos Sinos

                      N° 6 - Alphaville,Barueri, SP 06532-008</p>
              </div>
          </div>
  
          <div class="rodape-div-2">
              <div class="rodape-div-2-coluna">
                  <!-- elemento -->
                  <span><b>Contatos</b></span>
                  <p>jleecoffe@jlee.com</p>
                  <p>(11) 98222-1064</p>
              </div>
          </div>
  
          <div class="rodape-div-3">
              <div class="rodape-div-3-coluna">
                  <!-- elemento -->
                  <span><b>Links</b></span>
                  <p><a href="#servicos">Serviços</a></p>
                  <p><a href="#empresa">Empresa</a></p>
                  <p><a href="#sobre">Sobre</a></p>
              </div>
          </div>
  
          <div class="rodape-div-4">
              <div class="rodape-div-4-coluna">
                  <!-- elemento -->
                  <span><b>Outros</b></span>
                  <p>Políticas de Privacidade</p>
              </div>
          </div>
  
      </div>
      <p class="rodape-direitos">Copyright 2023 JLEE Cafeteria. Todos os direitos reservados..</p>
  </footer>
    </body>

    </html>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="fotosjlee/Coffee Shop Logo.jpg.png" type="image/x-icon">
    <title>JLEE Cafeteria - Tela de Bolo</title>
    <link rel="stylesheet" type="text/css" href="produtos.css" media="screen" />
</head>

    <body>
       
        <div class="topnav">
            <div class="Cadastrar">
              <a href="login.html" class="hoverborder"><img src="fotosjlee/usuario login.png" width="30px"heigth="50px" alt=""></a>
              <a href="entrar.html" class="hoverborder"><img src="fotosjlee/novo-usuario.png" width="30px"heigth="50px" alt=""></a>
            </div>
              <div class="logo">
                    <a href="index.html"><img src="fotosjlee/jlleeeeeeeeeeeeeeeeeeeeeee.jpg" alt="logotipo" width="140" height="140" ></a>
              </div>  
                  <header>
                  <div class="pescar">
            <input type="text" placeholder="Pesquisar..."class="pesquisar" >
            <br>     
            </div>
        </header>
        </div>
        <br> <br> <br> <br>

                <?php
                include "conexao.php";

                $check = $conn->prepare('SELECT * FROM produtos where categoria = "salgado"');

                $check->execute(array(

                ));

                if ($check->rowCount() > 0) {

                echo "<div>";
                foreach ($check as $linha) {
                echo "<a href='" .$linha['id'].".php'><div class='product'>";
                echo "<div class='produto'>" . $linha['produto'] . "</div><br>";
                echo "<img src='fotosjlee/".$linha['imagem']."' class='img'><br>";
                echo "<p class='descricao'>" . $linha['descricao'] . "</p><br>";
                echo $linha['valor'];
                echo "</div></a>";
                
                }
                $query = "SELECT quantidade FROM produtos";

                if (isset($_POST['add'])) {
                    $numero += 1;
                } elseif (isset($_POST['sub'])) {
                    $numero -= 1;
                }
                }
                ?>

<footer class="rodape" id="contato">
            <div class="rodape-div">

                <div class="rodape-div-1">
                    <div class="rodape-div-1-coluna">
                        <!-- elemento -->
                        <span><b>Endereço</b></span>
                        <p>Alameda Vale dos Sinos

                            N° 6 - Alphaville,Barueri, SP 06532-008</p>
                    </div>
                </div>
        
                <div class="rodape-div-2">
                    <div class="rodape-div-2-coluna">
                        <!-- elemento -->
                        <span><b>Contatos</b></span>
                        <p>jleecoffe@gmail.com</p>
                        <p>(11) 98222-1064</p>
                    </div>
                </div>
        
                <div class="rodape-div-3">
                    <div class="rodape-div-3-coluna">
                        <!-- elemento -->
                        <span><b>Links</b></span>
                        <p><a href="#servicos">Serviços</a></p>
                        <p><a href="#empresa">Empresa</a></p>
                        <p><a href="#sobre">Sobre</a></p>
                    </div>
                </div>
        
                <div class="rodape-div-4">
                    <div class="rodape-div-4-coluna">
                        <!-- elemento -->
                        <span><b>Outros</b></span>
                        <p>Políticas de Privacidade</p>
                    </div>
                </div>
        
            </div>
            <p class="rodape-direitos">Copyright 2023 JLEE Cafeteria. Todos os direitos reservados..</p>
        </footer>
    </body>

    </html>




<?php
include "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $cpf = $_POST['cpf'];
    $nascimento = $_POST['nascimento'];
    $telefone = $_POST['telefone'];
    $endereco = $_POST['endereco'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Verificar se algum campo está vazio
    if (empty($nome) || empty($sobrenome) || empty($cpf) || empty($nascimento) || empty($telefone) || empty($endereco) || empty($email) || empty($senha)) {
        echo "<script>alert('Campos não podem ser vazios!!!');history.go(-1);</script>";
    } else {
        try {
            // Criptografar a senha antes de inserir no banco
            $senhacript = password_hash($senha, PASSWORD_DEFAULT);

            $cliente = $conn->prepare('INSERT INTO cliente (nome, sobrenome, cpf, data_nascimento, telefone, endereco, email, senha) VALUES 
                (:nome, :sobrenome, :cpf, :nascimento, :telefone, :endereco, :email, :senha)');

            $cliente->execute(array(
                ':nome' => $nome,
                ':sobrenome' => $sobrenome,
                ':cpf' => $cpf,
                ':nascimento' => $nascimento,
                ':telefone' => $telefone,
                ':endereco' => $endereco,
                ':email' => $email,
                ':senha' => $senhacript,
            ));

            if ($cliente->rowCount() == 1) {
                echo '<script type="text/javascript">'; 
                echo 'alert("Cliente Cadastrado");'; 
                echo 'window.location.href ="index.html";';
                echo '</script>';
            } else {
                echo "<script>alert('Erro ao cadastrar');history.go(-1);</script>";
            }
        } catch (PDOException $e) {
            echo 'ERROR: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="fotosjlee/Coffee Shop Logo.jpg.png" type="image/x-icon">
    <title>JLEE Cafeteria - Tela de Bolo</title>
    <link rel="stylesheet" type="text/css" href="pagp.css" media="screen" />
</head>

    <body>
       
        <div class="topnav">
            <div class="Cadastrar">
              <a href="login.html" class="hoverborder"><img src="fotosjlee/usuario login.png" width="30px"heigth="50px" alt=""></a>
              <a href="entrar.html" class="hoverborder"><img src="fotosjlee/novo-usuario.png" width="30px"heigth="50px" alt=""></a>
            </div>
              <div class="logo">
                    <a href="index.html"><img src="fotosjlee/jlleeeeeeeeeeeeeeeeeeeeeee.jpg" alt="logotipo" width="140" height="140" ></a>
              </div>  
                  <header>
                  <div class="pescar">
            <input type="text" placeholder="Pesquisar..."class="pesquisar" >
            <br>
              
            </div>
        </header>
        </div>
        <br> <br> <br> <br>

                <?php
                include "conexao.php";

                $check = $conn->prepare('SELECT * FROM produtos where id = "35"');

                $check->execute(array(

                ));

                if ($check->rowCount() > 0) {

                echo "<div>";
                foreach ($check as $linha) {
                echo "<div class='product'>";
                echo "<div class='nomeprod'>" . $linha['produto'] . "</div><br>";
                echo "<div class:'imagem'>";
                echo "<img src='fotosjlee/".$linha['imagem']."' class='imagem'><br>";
                echo "</div>";
                echo "<p class='tagp'> Uma iguaria clássica que combina uma massa delicada e amanteigada com um recheio saboroso e irresistível. Cada mordida revela a textura delicada da massa, que se desfaz suavemente na boca, revelando um recheio generoso de frango temperado, palmito suculento, camarão delicado ou uma variedade de opções vegetarianas. Feitas com ingredientes frescos e assadas com maestria, as nossas Empadinhas na JLEE são a escolha ideal para os amantes de um lanche ou acompanhamento delicioso e reconfortante. Seja para um lanche rápido, um complemento para o seu café ou uma opção para o almoço, as Empadinhas na JLEE são a opção perfeita para aqueles que buscam uma experiência culinária caseira e satisfatória. Venha provar a excelência das nossas empadinhas na JLEE e permita-se saborear um clássico preparado com carinho e perfeição. </p><br><br><br><br><br><br><br><br><br><br><br>";
                echo "</div></a>";
                
                }
                echo "</div>";
                $query = "SELECT quantidade FROM produtos";

                if (isset($_POST['add'])) {
                    $numero += 1;
                } elseif (isset($_POST['sub'])) {
                    $numero -= 1;
                }
                }
                ?>

<footer class="rodape" id="contato">
      <div class="rodape-div">

          <div class="rodape-div-1">
              <div class="rodape-div-1-coluna">
                  <!-- elemento -->
                  <span><b>Endereço</b></span>
                  <p>Alameda Vale dos Sinos

                      N° 6 - Alphaville,Barueri, SP 06532-008</p>
              </div>
          </div>
  
          <div class="rodape-div-2">
              <div class="rodape-div-2-coluna">
                  <!-- elemento -->
                  <span><b>Contatos</b></span>
                  <p>jleecoffe@jlee.com</p>
                  <p>(11) 98222-1064</p>
              </div>
          </div>
  
          <div class="rodape-div-3">
              <div class="rodape-div-3-coluna">
                  <!-- elemento -->
                  <span><b>Links</b></span>
                  <p><a href="#servicos">Serviços</a></p>
                  <p><a href="#empresa">Empresa</a></p>
                  <p><a href="#sobre">Sobre</a></p>
              </div>
          </div>
  
          <div class="rodape-div-4">
              <div class="rodape-div-4-coluna">
                  <!-- elemento -->
                  <span><b>Outros</b></span>
                  <p>Políticas de Privacidade</p>
              </div>
          </div>
  
      </div>
      <p class="rodape-direitos">Copyright 2023 JLEE Cafeteria. Todos os direitos reservados..</p>
  </footer>
    </body>

    </html>


const slideContainer = document.querySelector(".carousel-slide");
const slides = document.querySelectorAll(".carousel-slide img");

let counter = 0;
const slideWidth = slides[0].clientWidth;

function nextSlide() {
    if (counter >= slides.length - 1) return;
    counter++;
    slideContainer.style.transform = `translateX(-${counter * slideWidth}px)`;
}

setInterval(nextSlide, 3000); // Troca de slide a cada 3 segundos

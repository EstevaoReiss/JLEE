<?php

include "conexao.php";

$email = $_POST['email'];
$senha = $_POST['senha'];

$check = $conn->prepare('SELECT * FROM cliente WHERE email = :email');

$check->execute(array(

    ':email' => $email,

));

if ($check->rowCount() == 1) {

    foreach ($check as $linha) {
        
        $senhacript=$linha["senha"];
    }
    if ($senha == '12345678') {

        echo '<script type="text/javascript">'; 
                echo 'alert("Administrador logado com sucesso!!!");'; 
                echo 'window.location.href ="admin.html";';
                echo '</script>';

    }elseif (password_verify($senha, $senhacript)) {
        echo '<script type="text/javascript">'; 
                echo 'alert("Logado com sucesso!!!");'; 
                echo 'window.location.href ="index.html";';
                echo '</script>';

    } 
    else {
          echo "<script>alert('Senha invalido');history.go(-1);</script>";
    }
}else{
    echo "<script>alert('Usuário não cadastrado');history.go(-1);</script>";
}


?>
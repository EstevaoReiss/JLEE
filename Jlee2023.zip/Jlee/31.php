<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="fotosjlee/Coffee Shop Logo.jpg.png" type="image/x-icon">
    <title>JLEE Cafeteria - Tela de Bolo</title>
    <link rel="stylesheet" type="text/css" href="pagp.css" media="screen" />
</head>

    <body>
       
        <div class="topnav">
            <div class="Cadastrar">
              <a href="login.html" class="hoverborder"><img src="fotosjlee/usuario login.png" width="30px"heigth="50px" alt=""></a>
              <a href="entrar.html" class="hoverborder"><img src="fotosjlee/novo-usuario.png" width="30px"heigth="50px" alt=""></a>
            </div>
              <div class="logo">
                    <a href="index.html"><img src="fotosjlee/jlleeeeeeeeeeeeeeeeeeeeeee.jpg" alt="logotipo" width="140" height="140" ></a>
              </div>  
                  <header>
                  <div class="pescar">
            <input type="text" placeholder="Pesquisar..."class="pesquisar" >
            <br>
               
            </div>
        </header>
        </div>
        <br> <br> <br> <br>

                <?php
                include "conexao.php";

                $check = $conn->prepare('SELECT * FROM produtos where id = "31"');

                $check->execute(array(

                ));

                if ($check->rowCount() > 0) {

                echo "<div>";
                foreach ($check as $linha) {
                echo "<div class='product'>";
                echo "<div class='nomeprod'>" . $linha['produto'] . "</div><br>";
                echo "<div class:'imagem'>";
                echo "<img src='fotosjlee/".$linha['imagem']."' class='imagem'><br>";
                echo "</div>";
                echo "<p class='tagp'> Uma iguaria brasileira irresistível que combina a crocância por fora com a maciez e o sabor marcante do queijo por dentro. Cada mordida revela uma experiência de textura única, com uma casquinha dourada e crocante que contrasta perfeitamente com o interior leve e aerado, repleto de um delicioso sabor de queijo. Preparado com ingredientes de alta qualidade e assado com perfeição, o nosso Pão de Queijo na JLEE é a opção ideal para os amantes de um lanche saboroso e reconfortante. Seja para um café da manhã rápido ou um lanche delicioso a qualquer hora do dia, o Pão de Queijo é a escolha perfeita para aqueles que buscam uma experiência autêntica e satisfatória. Venha saborear a autenticidade do Pão de Queijo na JLEE e permita-se desfrutar de um pedacinho do Brasil a cada mordida. </p><br><br><br><br><br><br><br><br><br><br><br>";
                echo "</div></a>";
                
                }
                echo "</div>";
                $query = "SELECT quantidade FROM produtos";

                if (isset($_POST['add'])) {
                    $numero += 1;
                } elseif (isset($_POST['sub'])) {
                    $numero -= 1;
                }
                }
                ?>

<footer class="rodape" id="contato">
      <div class="rodape-div">

          <div class="rodape-div-1">
              <div class="rodape-div-1-coluna">
                  <!-- elemento -->
                  <span><b>Endereço</b></span>
                  <p>Alameda Vale dos Sinos

                      N° 6 - Alphaville,Barueri, SP 06532-008</p>
              </div>
          </div>
  
          <div class="rodape-div-2">
              <div class="rodape-div-2-coluna">
                  <!-- elemento -->
                  <span><b>Contatos</b></span>
                  <p>jleecoffe@jlee.com</p>
                  <p>(11) 98222-1064</p>
              </div>
          </div>
  
          <div class="rodape-div-3">
              <div class="rodape-div-3-coluna">
                  <!-- elemento -->
                  <span><b>Links</b></span>
                  <p><a href="#servicos">Serviços</a></p>
                  <p><a href="#empresa">Empresa</a></p>
                  <p><a href="#sobre">Sobre</a></p>
              </div>
          </div>
  
          <div class="rodape-div-4">
              <div class="rodape-div-4-coluna">
                  <!-- elemento -->
                  <span><b>Outros</b></span>
                  <p>Políticas de Privacidade</p>
              </div>
          </div>
  
      </div>
      <p class="rodape-direitos">Copyright 2023 JLEE Cafeteria. Todos os direitos reservados..</p>
  </footer>
    </body>

    </html>

